<div class="d-md-flex"> 

<div class="form-group">
           
            <select class="form-control" id="department_id" name="department_id">
            <option value="" selected disabled hidden>รหัสสาขาวิชา</option>
            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->department_id); ?>"><?php echo e($item->department_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

       
<div class="form-group">
           
            <select class="form-control" id="department_name" name="department_name">
            <option value="" selected disabled hidden>ชื่อสาขาวิชา</option>
            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->department_name); ?>"><?php echo e($item->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        
<div class="form-group">
           
            <select class="form-control"  name="course_id" id="secondmenu">
            <option value="" selected disabled hidden>รหัสหลักสูตร</option>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->course_id); ?>"><?php echo e($item->course_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>





        
<div class="form-group">
           
            <select class="form-control" name="course_name" id="firstmenu">
            <option value="" selected disabled hidden>ชื่อหลักสูตร</option>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->course_name); ?>"><?php echo e($item->course_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


</div>
<div class="d-md-flex"> 
        
<div class="form-group">
           
            <select class="form-control" id="category2" name="category_name">
            <option value="" selected disabled hidden>ชื่อหมวดวิชา</option>
            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->category_name); ?>"><?php echo e($item->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
<div class="form-group">
           
            <select class="form-control" id="category1" name="category_id">
            <option value="" selected disabled hidden>รหัสหมวดวิชา</option>
            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->category_id); ?>"><?php echo e($item->category_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


<div class="form-group">
           
            <select class="form-control" id="group2" name="group_name">
            <option value="" selected disabled hidden>ชื่อกลุ่มวิชา</option>
            <?php $__currentLoopData = $subgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->group_name); ?>"><?php echo e($item->group_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

      
<div class="form-group">
           
            <select class="form-control" id="group1" name="group_id">
            <option value="" selected disabled hidden>รหัสกลุ่มวิชา</option>
            <?php $__currentLoopData = $subgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->group_id); ?>"><?php echo e($item->group_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


</div>



<div class="form-group <?php echo e($errors->has('subject_id') ? 'has-error' : ''); ?>">
    <label for="subject_id" class="control-label"><?php echo e('รหัสรายวิชา'); ?></label>
    <input class="form-control" name="subject_id" type="text" id="subject_id" value="<?php echo e(isset($manage_course->subject_id) ? $manage_course->subject_id : ''); ?>" >
    <?php echo $errors->first('subject_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('subject_name') ? 'has-error' : ''); ?>">
    <label for="subject_name" class="control-label"><?php echo e('ชื่อรายวิชา'); ?></label>
    <input class="form-control" name="subject_name" type="text" id="subject_name" value="<?php echo e(isset($manage_course->subject_name) ? $manage_course->subject_name : ''); ?>" >
    <?php echo $errors->first('subject_name', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('subject_credit') ? 'has-error' : ''); ?>">
    <label for="subject_credit" class="control-label"><?php echo e('หน่วยกิต'); ?></label>
    <input class="form-control" name="subject_credit" type="text" id="subject_credit" value="<?php echo e(isset($manage_course->subject_credit) ? $manage_course->subject_credit : ''); ?>" >
    <?php echo $errors->first('subject_credit', '<p class="help-block">:message</p>'); ?>

</div>




<script type="text/javascript">
        window.onload = function() {
   document.getElementById("firstmenu").addEventListener('change',function(e) {ha(e,'secondmenu');}, false);
   document.getElementById("secondmenu").addEventListener('change',function(e) {ha(e,'firstmenu');}, false);

   document.getElementById("category1").addEventListener('change',function(e) {ha1(e,'category2');}, false);
   document.getElementById("category2").addEventListener('change',function(e) {ha1(e,'category1');}, false);

   document.getElementById("group1").addEventListener('change',function(e) {ha1(e,'group2');}, false);
   document.getElementById("group2").addEventListener('change',function(e) {ha1(e,'group1');}, false);
   
   
};
function ha (e,id){
   var index = e.target.selectedIndex;
   document.getElementById(id).selectedIndex = index;

}

   function ha1 (e,id){
   var index = e.target.selectedIndex;
   document.getElementById(id).selectedIndex = index;
}

function ha2 (e,id){
   var index = e.target.selectedIndex;
   document.getElementById(id).selectedIndex = index;

};

    </script>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/manage_course/form.blade.php ENDPATH**/ ?>