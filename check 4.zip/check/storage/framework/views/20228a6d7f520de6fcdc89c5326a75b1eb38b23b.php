

<label for="category_id" class="control-label"><?php echo e('รหัสหมวดวิชา'); ?></label>
<div class="form-group">
           
            <select class="form-control" id="category_id" name="category_id">
            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->category_id); ?>"><?php echo e($item->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

<div class="form-group <?php echo e($errors->has('group_id') ? 'has-error' : ''); ?>">
    <label for="group_id" class="control-label"><?php echo e('รหัสกลุ่มวิชา'); ?></label>
    <input class="form-control" name="group_id" type="text" id="group_id" value="<?php echo e(isset($subgroup->group_id) ? $subgroup->group_id : ''); ?>" >
    <?php echo $errors->first('group_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('group_name') ? 'has-error' : ''); ?>">
    <label for="group_name" class="control-label"><?php echo e('ชื่อกลุ่มวิชา'); ?></label>
    <input class="form-control" name="group_name" type="group_name" id="group_name" value="<?php echo e(isset($subgroup->group_name) ? $subgroup->group_name : ''); ?>" >
    <?php echo $errors->first('group_name', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/subgroup/form.blade.php ENDPATH**/ ?>