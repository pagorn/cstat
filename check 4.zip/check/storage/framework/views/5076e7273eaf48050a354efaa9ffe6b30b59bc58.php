<div class="form-group <?php echo e($errors->has('department_id') ? 'has-error' : ''); ?>">
    <label for="department_id" class="control-label"><?php echo e('รหัสสาขาวิชา'); ?></label>
    <input class="form-control" name="department_id" type="text" id="department_id" value="<?php echo e(isset($department->department_id) ? $department->department_id : ''); ?>" >
    <?php echo $errors->first('department_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('department_name') ? 'has-error' : ''); ?>">
    <label for="department_name" class="control-label"><?php echo e('ชื่อสาขาวิชา'); ?></label>
    <input class="form-control" name="department_name" type="text" id="department_name" value="<?php echo e(isset($department->department_name) ? $department->department_name : ''); ?>" >
    <?php echo $errors->first('department_name', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/department/form.blade.php ENDPATH**/ ?>