<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Graduation Completed Status Checking System</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>





        <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/admin/grade')); ?>">
                ระบบตรวจสอบผู้สำเร็จการศึกษา
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
  
                

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                  
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
  </div>
</nav>

</div>
    <div class="container">
        <div class="row">
            
 
            <div class="col">

                <div class="card">

         
                    <div class="card-header">Create New grade</div>
                    
                    <div class="card-body">

  

                        <a href="<?php echo e(url('/admin/grade')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/admin/grade')); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                       
                            <?php echo e(csrf_field()); ?>

                            <div class="d-md-flex"> 
                            <div class="form-group <?php echo e($errors->has('student_id') ? 'has-error' : ''); ?>">
    <label for="student_id" class="control-label"><?php echo e('รหัสนักศึกษา'); ?></label>
    <input readonly class="form-control" name="student_id" type="text" id="student_id" value="<?php echo e(Auth::user()->student_id); ?>" >
    <?php echo $errors->first('student_id', '<p class="help-block">:message</p>'); ?>

</div>






<div class="form-group <?php echo e($errors->has('department_id') ? 'has-error' : ''); ?>">
    <label for="department_id" class="control-label"><?php echo e('รหัสสาขาวิชา'); ?></label>
    <input readonly class="form-control" name="department_id" type="text" id="department_id" value="1" >
    <?php echo $errors->first('department_id', '<p class="help-block">:message</p>'); ?>

</div>



<div class="form-group <?php echo e($errors->has('course_id') ? 'has-error' : ''); ?>">
    <label for="course_id" class="control-label"><?php echo e('รหัสหลักสูตร'); ?></label>
    <input readonly class="form-control" name="course_id" type="text" id="course_id" value="310234601160" >
    <?php echo $errors->first('course_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('course_name') ? 'has-error' : ''); ?>">
    <label for="course_name" class="control-label"><?php echo e('ชื่อหลักสูตร'); ?></label>
    <input readonly class="form-control" name="course_name" type="text" id="course_name" value="สารสนเทศสถิติ" >
    <?php echo $errors->first('course_name', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('group_id') ? 'has-error' : ''); ?>">
    <label for="group_id" class="control-label"><?php echo e('รหัสกลุ่มวิชา'); ?></label>
    <input readonly class="form-control" name="group_id" type="text" id="group_id" value="204" >
    <?php echo $errors->first('group_id', '<p class="help-block">:message</p>'); ?>

</div>



<div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
    <label for="category_id" class="control-label"><?php echo e('รหัสหมวดวิชา'); ?></label>
    <input readonly class="form-control" name="category_id" type="text" id="category_id" value="3" >
    <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

</div>

</div>


<div class="form-group <?php echo e($errors->has('subject_id') ? 'has-error' : ''); ?>">
    <label for="subject_id" class="control-label"><?php echo e('รหัสรายวิชา'); ?></label>
    <input  class="form-control" name="subject_id" type="text" id="subject_id" value="<?php echo e(isset($grade->subject_id) ? $grade->subject_id : ''); ?>" >
    <?php echo $errors->first('subject_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('subject_name') ? 'has-error' : ''); ?>">
    <label for="subject_name" class="control-label"><?php echo e('ชื่อรายวิชา'); ?></label>
    <input  class="form-control" name="subject_name" type="text" id="subject_name" value="<?php echo e(isset($grade->subject_name) ? $grade->subject_name : ''); ?>" >
    <?php echo $errors->first('subject_name', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('subject_credit') ? 'has-error' : ''); ?>">
    <label for="subject_credit" class="control-label"><?php echo e('หน่วยกิต'); ?></label>
    <input  class="form-control" name="subject_credit" type="text" id="subject_credit" value="<?php echo e(isset($grade->subject_credit) ? $grade->subject_credit : ''); ?>" >
    <?php echo $errors->first('subject_credit', '<p class="help-block">:message</p>'); ?>

</div>



<label for="grade1" class="control-label"><?php echo e('เกรดรายวิชา'); ?></label>
<div class="form-group <?php echo e($errors->has('grade1') ? 'has-error' : ''); ?>">
    
    <select name="grade1" placeholder="หลักสูตร" class="form-control" id="grade1" >
    <option value="4">A</option>
   <option value="3.5">B+</option>
   <option value="3">B</option>
   <option value="2.5">C+</option>
   <option value="2">C</option>
   <option value="1.5">D+</option>
   <option value="1">D</option>
   <option value="0">F</option>
   <option value="S">S</option>
   <option value="U">U</option>

</select>
    <?php echo $errors->first('faculty', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" >
</div>


                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/create1.blade.php ENDPATH**/ ?>