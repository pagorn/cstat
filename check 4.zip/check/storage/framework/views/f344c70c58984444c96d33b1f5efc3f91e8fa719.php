

<div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
    <label for="status" class="control-label"><?php echo e('สถานะ'); ?></label>
    <select name="status" class="form-control" id="status" >
    <?php $__currentLoopData = json_decode('{"ไม่ผ่านการตรวจสอบ": "ไม่ผ่านการตรวจสอบ", "รอยืนยันผลการศึกษา": "รอยืนยันผลการศึกษา", "จบการศึกษา": "จบการศึกษา"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($optionKey); ?>" <?php echo e((isset($report->status) && $report->status == $optionKey) ? 'selected' : ''); ?>><?php echo e($optionValue); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('ps') ? 'has-error' : ''); ?>">
    <label for="ps" class="control-label"><?php echo e('หมายเหตุ'); ?></label>
    <input class="form-control" name="ps" type="text" id="ps" value="<?php echo e(isset($report->ps) ? $report->ps : ''); ?>" >
    <?php echo $errors->first('ps', '<p class="help-block">:message</p>'); ?>

</div>









<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/report/form.blade.php ENDPATH**/ ?>