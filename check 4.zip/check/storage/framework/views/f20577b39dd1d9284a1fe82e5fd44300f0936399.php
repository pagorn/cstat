

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            

            <div class="col">
                <div class="card">
                    <div class="card-header">Create New course</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/courses')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/admin/courses')); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                          

                            <label for="department_id" class="control-label"><?php echo e('รหัสสาขาวิชา'); ?></label>
<div class="form-group">
           
            <select class="form-control" id="department_id" name="department_id">
            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->department_id); ?>"><?php echo e($item->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

<div class="form-group <?php echo e($errors->has('course_id') ? 'has-error' : ''); ?>">
    <label for="course_id" class="control-label"><?php echo e('รหัสหลักสูตร'); ?></label>
    <input class="form-control" name="course_id" type="text" id="course_id" value="<?php echo e(isset($courses->course_id) ? $courses->course_id : ''); ?>" >
    <?php echo $errors->first('course_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('course_name') ? 'has-error' : ''); ?>">
    <label for="course_name" class="control-label"><?php echo e('ชื่อหลักสูตร'); ?></label>
    <input class="form-control" name="course_name" type="text" id="course_name" value="<?php echo e(isset($courses->course_name) ? $courses->course_name : ''); ?>" >
    <?php echo $errors->first('course_name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" >
</div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/courses/create.blade.php ENDPATH**/ ?>