<div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
    <label for="category_id" class="control-label"><?php echo e('รหัสหมวดวิชา'); ?></label>
    <input class="form-control" name="category_id" type="text" id="category_id" value="<?php echo e(isset($subcategory->category_id) ? $subcategory->category_id : ''); ?>" >
    <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('category_name') ? 'has-error' : ''); ?>">
    <label for="category_name" class="control-label"><?php echo e('ชื่อหมวดวิชา'); ?></label>
    <input class="form-control" name="category_name" type="text" id="category_name" value="<?php echo e(isset($subcategory->category_name) ? $subcategory->category_name : ''); ?>" >
    <?php echo $errors->first('category_name', '<p class="help-block">:message</p>'); ?>

</div>



<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/subcategory/form.blade.php ENDPATH**/ ?>