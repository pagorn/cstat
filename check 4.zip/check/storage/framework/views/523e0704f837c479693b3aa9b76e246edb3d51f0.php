<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Graduation Completed Status Checking System</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
</head>
<body>





        <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/admin/grade')); ?>">
                ระบบตรวจสอบผู้สำเร็จการศึกษา
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
  

                <div class="dropdown show">
  <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  บันทึกเกรด
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="grade/create">บันทึกเกรดหมวดวิชาศึกษาทั่วไป/หมวดวิชาเฉพาะ</a>
    <a class="dropdown-item" href="create1">บันทึกเกรดหมวดเลือกเสรี</a>

  </div>


  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
  กรณีเปลี่ยนวิชาเลือกเป็นเลือกเสรี
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header btn btn-primary ">
        <h5 class="modal-title" id="exampleModalLongTitle">กรณีเปลี่ยนวิชาเลือกเป็นเลือกเสรี</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      ตรวจสอบเงื่อนไขการสำเร็จการศึกษา<br>
1.นักศึกษาบันทึกเกรดตามหมวดรายวิชาให้ครบตามหลักสูตร และถูกต้องตามความเป็นจริง <br>
2.บันทึกเกรดเลือกเสรี นักศึกษากรอกรหัสวิชา ชื่อรายวิชา หน่วยกิตให้ถูกต้องตรงตามความเป็นจริง<br>
3.ในกรณีที่ต้องการโยกย้ายรายวิชาในหมวดวิชาเลือกเป็นหมวดวิชาเลือกเสรี นักศึกษาจะต้องลบรายวิชาดังกล่าว ก่อนเข้าบันทึกเกรดหมวดเลือกเสรี<br>
4.ยื่นเอกสารตรวจสอบจบ สำหรับนักศึกษาชั้นปีที่ 4 หรือนักศึกษาที่คาดว่าจะสำเร็จการศึกษาเท่านั้น นักศึกษาจะต้องตรวจสอบความถูกต้อง ว่าลงทะเบียนครบทุกรายวิชาตามหลักสูตร บันทึกเกรด และอื่นๆ ก่อนกดส่ง เนื่องจากระบบจะนำส่งผลการตรวจสอบให้กับเจ้าหน้าที่งานบริการศึกษาตรวจสอบต่อไป และไม่สามารถกลับมาแก้ไขได้<br>
5.Export Doc กรุณานำส่งเอกสารให้อาจารย์ที่ปรึกษาลงนาม<br>
6.เงื่อนไขการสำเร็จการศึกษามี 5 เงื่อนไข ได้แก่ <br>1)หน่วยกิตที่ลงทะเบียนครบตามหลักสูตร <br>2)เกรดเฉลี่ยรวม 2.00 ขึ้นไป<br> 3)เกรดเฉลี่ยเฉพาะหลักสูตร 2.00 ขึ้นไป <br>4)หน่วยกิตกิจกรรมทุกด้าน 60 ขึ้นไป  <br>5)ไม่มีหนี้สิน หรือไม่ติดหมวกกันน็อค ซึ่งอีก 2 เงื่อนไขหลัง นักศึกษาจะต้องตรวจสอบด้วยตนเอง<br>
      </div>
   
    </div>
  </div>
</div>

<?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!empty($item->student_id==$student_id)): ?>
             <?php else: ?>
             <a href="report/create" class="btn btn-primary "  role="button" aria-pressed="true">ส่งข้อมูลเพื่อตรวจสอบ</a>                  
       
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if(!empty($item->edit1==1)): ?>
<a href="<?php echo e($edit_id); ?>/edit1" class="btn btn-primary "  role="button" aria-pressed="true">ปรับปรุงข้อมูลเพื่อตรวจสอบ</a>                  
                    <?php else: ?>
                    
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <a href="grade/show" target="_blank" class="btn btn-primary " role="button" aria-pressed="true">Export Doc</a>

</div>






    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                  
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
  </div>
</nav>

</div>
    <div class="container">
    <div class="row">
         
      
            <div class="col">
                <div class="card">          
                    <div class="card-header">   <h5>ผลการอนุมัติ</h5></div>
                    <div class="card-body">

    <div class="d-md-flex">
    <div> <p><strong>โครงสร้างหลักสูตร: </strong><?php echo Auth::user()->course_id; ?></p></div>
    <div>  <p><strong> &nbsp;ชื่อหลักสูตร : </strong><?php echo Auth::user()->course_name; ?></p></div></div>
    <div class="d-md-flex">
    <div> <p><strong>ชื่อ-สกุล : </strong><?php echo Auth::user()->name; ?></p></div>
    <div>  <p><strong> &nbsp;รหัสนักศึกษา : </strong><?php echo Auth::user()->student_id; ?></p></div></div>
    

    

<p><b>คำชี้แจ้ง:</b> คลิกเพื่อเปลี่ยนสถานะ การทดสอบคอมพิวเตอร์ของสำนักนวัตกรรมการเรียนการสอน, หน่วยกิจกรรมครบ 5 ด้าน 60 หน่วยกิจกรรม, ผ่านการทดสอบภาษาอังกฤษ</p>

    <div class="card">
   
   <div class="card-body">
    
      <h5 class="card-title ">การทดสอบคอมพิวเตอร์ของสำนักนวัตกรรมการเรียนการสอน</h5>
      
      <p class="card-text">        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status1 == 1): ?> 
        <form action="<?php echo e(route('completedUpdate1', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate1', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                 
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
    
    <div class="card-body">
      <h5 class="card-title">หน่วยกิจกรรมครบ 5 ด้าน 60 หน่วยกิจกรรม</h5>
      
      <p class="card-text">     <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status2 == 1): ?> 
    <form action="<?php echo e(route('completedUpdate2', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate2', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                  
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">ผ่านการทดสอบภาษาอังกฤษ</h5>
      
      <p class="card-text">   <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status3 == 1): ?> 
    <form action="<?php echo e(route('completedUpdate3', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate3', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                   
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
 







          
      </div>
                </div>
            </div>
        </div>
    </div> </div> 
      

    <div class="container">
        <div class="row">
         
      
            <div class="col">
                <div class="card">
                    

                    
                    <div class="card-body">
                      

                   
  
  
  
  <div class="card-group">
  <div class="card">
 
    <div class="card-body ">
    
      <h5 class="card-title ">จำนวนหน่วยกิตรวมขั้นต่ำ: <?php echo e($credit_sum); ?></h5>
      <p class="card-text">จำนวนหน่วยกิตที่ได้: <?php echo e($sum_credit); ?> </p>
      <p class="card-text">       <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($credit_sum)>$sum_credit): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
    
    <div class="card-body">
      <h5 class="card-title">เกรดเฉลี่ยรวมไม่ต่ำกว่า: 2.00</h5>
      <p class="card-text">เกรดเฉลี่ยรวมที่ได้: <?php echo e(number_format($sum_gpa, 2)); ?></p>
      <p class="card-text">     <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($sum_gpa)<2): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">เกรดเฉลี่ยเฉพาะหลักสูตรไม่ต่ำกว่า: 2.00</h5>
      <p class="card-text">เกรดเฉลี่ยเฉพาะหลักสูตรที่ได้: <?php echo e(number_format($sum_gpa_1, 2)); ?> </p>
      <p class="card-text">     <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($sum_gpa_1)<2): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
</div>
  
  

  
  <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>โครงสร้างหลักสูตร</th><th>หน่วยกิตตามเกณฑ์</th><th>หน่วยกิตที่ลงทะเบียน</th><th>หน่วยกิตที่ผ่าน</th><th>หน่วยกิตที่ยังขาด</th><th>GPA</th><th>เงื่อนไข</th>
                                    </tr>
                                </thead>
                                <tbody>
                               
                                    <tr>
                                        
                                        <td><b>1. หมวดวิชาศึกษาทั่วไป</b></td>
                                        <td><?php echo e($credit1); ?> </td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>

                                  
                                        <td><?php echo e(number_format($gpa_1, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_1)<12 or ($count_credit_2)<9 or ($count_credit_3)<9): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>
                                 
                                


                                 
                               
                                    <tr>
                                        
                                        <td>1.1 กลุ่มวิชาภาษา</td>
                                        <td><?php echo e($credit4); ?></td>
                                        <td><?php echo e($count_credit_sum1); ?></td>
                                        <td><?php echo e($count_credit_1); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_1)<$credit4): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit4-($count_credit_1)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_1, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_1)<$credit4): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                        
                                        <td>1.2 กลุ่มวิชามนุษยศาสตร์และสังคมศาสตร์</td>
                                        <td><?php echo e($credit5); ?></td>
                                        <td><?php echo e($count_credit_sum2); ?></td>
                                        <td><?php echo e($count_credit_2); ?></td>
                                        <td>
                                        <?php if(($count_credit_2)<$credit5): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit5-($count_credit_2)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?> 
                                        
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_2, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_2)<$credit5): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>



                                    <tr>
                                        
                                        <td>1.3 กลุ่มคณิตศาสตร์และวิทยาศาสตร์</td>
                                        <td><?php echo e($credit6); ?></td>
                                        <td><?php echo e($count_credit_sum3); ?></td>
                                        <td><?php echo e($count_credit_3); ?></td>
                                        <td>
                                        <?php if(($count_credit_3)<$credit6): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit6-($count_credit_3)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_3, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_3)<$credit6): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>




                                    <tr>
                                        
                                        <td><b>2. หมวดวิชาเฉพาะ</b></td>
                                        <td><?php echo e($credit2); ?> </td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>

                                  
                                        <td><?php echo e(number_format($gpa_2, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_4)<36 or ($count_credit_6)<46 or ($count_credit_7)<15): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                    <td>2.1 กลุ่มวิชาพื้นฐาน</td>
                                        <td><?php echo e($credit7); ?></td>
                                        <td><?php echo e($count_credit_sum4); ?></td>
                                        <td><?php echo e($count_credit_4); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_4)<$credit7): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit7-($count_credit_4)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_4, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_4)<$credit7): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                   


                                    
                                    <tr>
                                    <td>2.2 กลุ่มวิชาบังคับ</td>
                                        <td><?php echo e($credit8); ?></td>
                                        <td><?php echo e($count_credit_sum6); ?></td>
                                        <td><?php echo e($count_credit_6); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_6)<$credit8): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit8-($count_credit_6)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_6, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_6)<$credit8): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                    <td>2.3 กลุ่มวิชาเลือก</td>
                                        <td><?php echo e($credit9); ?></td>
                                        <td><?php echo e($count_credit_sum7); ?></td>
                                        <td><?php echo e($count_credit_7); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_7)<$credit9): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit9-($count_credit_7)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_7, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_7)<$credit9): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>




                                    <tr>
                                    <td><b>3. หมวดเลือกเสรี</b></td>
                                        <td><?php echo e($credit3); ?></td>
                                        <td><?php echo e($count_credit_sum8); ?></td>
                                        <td><?php echo e($count_credit_8); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_8)<$credit3): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit3-($count_credit_8)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>

                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_8, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_8)<$credit3): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>









    <div class="container">
        <div class="row">
         
      
            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มวิชาภาษา <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum1); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_1, 2)); ?></h5></div>
                    <div class="card-body">
             
                      

                    
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>

                    
                    <?php endif; ?></td>

                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                      
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มวิชามนุษยศาสตร์และสังคมศาสตร์ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum2); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_2, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>

                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>






    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มคณิตศาสตร์และวิทยาศาสตร์ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum3); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_3, 2)); ?></h5></div>
                    <div class="card-body">
                     

              

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    

    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาพื้นฐาน <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum4); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_4, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>







    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาบังคับ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum6); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_6, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>





    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาเลือก <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum7); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_7, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเลือกเสรี <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum8); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_8, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th><th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/grade/' . $item->id . '/edit')); ?>" title="Edit grade"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> แก้ไข</button></a>

                                            <form method="POST" action="<?php echo e(url('/admin/grade' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete grade" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> ลบ</button>
                                            </form>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </body>
</html><?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/grade/index.blade.php ENDPATH**/ ?>