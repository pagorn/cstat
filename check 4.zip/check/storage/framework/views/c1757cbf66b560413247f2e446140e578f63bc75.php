

<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row">
         
      
            <div class="col">
                <div class="card">
                    <div class="card-header">    <h5>ผลการอนุมัติ</h5></div>
                    <div class="card-body">
                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-md-flex">
    <div> <p><strong>โครงสร้างหลักสูตร: </strong><?php echo e($item->course_id); ?> </p></div>
    <div>  <p><strong> &nbsp;ชื่อหลักสูตร : </strong><?php echo e($item->course_name); ?> </p></div></div>
    <div class="d-md-flex">
    <div> <p><strong>ชื่อ-สกุล : </strong><?php echo e($item->name); ?></p></div>
    <div>  <p><strong> &nbsp;รหัสนักศึกษา : </strong><?php echo e($item->student_id); ?>  </p></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    

    <div class="card-group">
  <div class="card">
 
    <div class="card-body ">
    
      <h5 class="card-title ">การทดสอบคอมพิวเตอร์ของสำนักนวัตกรรมการเรียนการสอน</h5>
      
      <p class="card-text">        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status1 == 1): ?> 
        <form action="<?php echo e(route('completedUpdate1', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate1', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                 
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
    
    <div class="card-body">
      <h5 class="card-title">หน่วยกิจกรรมครบ 5 ด้าน 60 หน่วยกิจกรรม</h5>
      
      <p class="card-text">     <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status2 == 1): ?> 
    <form action="<?php echo e(route('completedUpdate2', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate2', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                  
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">ผ่านการทดสอบภาษาอังกฤษ</h5>
      
      <p class="card-text">   <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <?php if($item->status3 == 1): ?> 
    <form action="<?php echo e(route('completedUpdate3', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                          
            <button type="submit" class="btn-sm btn-success" name="changeStatus" value="0">ผ่าน</button>
        </form>                    
    <?php else: ?>
        <form action="<?php echo e(route('completedUpdate3', $item->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>                              
            <button type="submit" class="btn-sm btn-danger" name="changeStatus" value="1">ไม่ผ่าน</button>
        </form>                                                   
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
</div>

    

          
      </div>
                </div>
            </div>
        </div>
    </div> 
   

    <div class="container">
        <div class="row">
         
      
            <div class="col">
                <div class="card">
                    

                    
                    <div class="card-body">
                      

                   
  
  
                    <div class="card-group">
  <div class="card">
 
    <div class="card-body ">
    
      <h5 class="card-title ">จำนวนหน่วยกิตรวมขั้นต่ำ: <?php echo e($credit_sum); ?></h5>
      <p class="card-text">จำนวนหน่วยกิตที่ได้: <?php echo e($sum_credit); ?> </p>
      <p class="card-text">       <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($credit_sum)>$sum_credit): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
    
    <div class="card-body">
      <h5 class="card-title">เกรดเฉลี่ยรวมไม่ต่ำกว่า: 2.00</h5>
      <p class="card-text">เกรดเฉลี่ยรวมที่ได้: <?php echo e(number_format($sum_gpa, 2)); ?></p>
      <p class="card-text">     <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($sum_gpa)<2): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
  <div class="card">
   
    <div class="card-body">
      <h5 class="card-title">เกรดเฉลี่ยเฉพาะหลักสูตรไม่ต่ำกว่า: 2.00</h5>
      <p class="card-text">เกรดเฉลี่ยเฉพาะหลักสูตรที่ได้: <?php echo e(number_format($sum_gpa_1, 2)); ?> </p>
      <p class="card-text">     <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($sum_gpa_1)<2): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
    </div>
  </div>
</div>
  
  
  
  
<div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>โครงสร้างหลักสูตร</th><th>หน่วยกิตตามเกณฑ์</th><th>หน่วยกิตที่ลงทะเบียน</th><th>หน่วยกิตที่ผ่าน</th><th>หน่วยกิตที่ยังขาด</th><th>GPA</th><th>เงื่อนไข</th>
                                    </tr>
                                </thead>
                                <tbody>
                               
                                    <tr>
                                        
                                        <td><b>1. หมวดวิชาศึกษาทั่วไป</b></td>
                                        <td><?php echo e($credit1); ?> </td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>

                                  
                                        <td><?php echo e(number_format($gpa_1, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_1)<12 or ($count_credit_2)<9 or ($count_credit_3)<9): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>
                                 
                                


                                 
                               
                                    <tr>
                                        
                                        <td>1.1 กลุ่มวิชาภาษา</td>
                                        <td><?php echo e($credit4); ?></td>
                                        <td><?php echo e($count_credit_sum1); ?></td>
                                        <td><?php echo e($count_credit_1); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_1)<$credit4): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit4-($count_credit_1)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_1, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_1)<$credit4): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                        
                                        <td>1.2 กลุ่มวิชามนุษยศาสตร์และสังคมศาสตร์</td>
                                        <td><?php echo e($credit5); ?></td>
                                        <td><?php echo e($count_credit_sum2); ?></td>
                                        <td><?php echo e($count_credit_2); ?></td>
                                        <td>
                                        <?php if(($count_credit_2)<$credit5): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit5-($count_credit_2)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?> 
                                        
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_2, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_2)<$credit5): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>



                                    <tr>
                                        
                                        <td>1.3 กลุ่มคณิตศาสตร์และวิทยาศาสตร์</td>
                                        <td><?php echo e($credit6); ?></td>
                                        <td><?php echo e($count_credit_sum3); ?></td>
                                        <td><?php echo e($count_credit_3); ?></td>
                                        <td>
                                        <?php if(($count_credit_3)<$credit6): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit6-($count_credit_3)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_3, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_3)<$credit6): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>




                                    <tr>
                                        
                                        <td><b>2. หมวดวิชาเฉพาะ</b></td>
                                        <td><?php echo e($credit2); ?> </td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>

                                  
                                        <td><?php echo e(number_format($gpa_2, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_4)<36 or ($count_credit_6)<46 or ($count_credit_7)<15): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                    <td>2.1 กลุ่มวิชาพื้นฐาน</td>
                                        <td><?php echo e($credit7); ?></td>
                                        <td><?php echo e($count_credit_sum4); ?></td>
                                        <td><?php echo e($count_credit_4); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_4)<$credit7): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit7-($count_credit_4)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_4, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_4)<$credit7): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                   


                                    
                                    <tr>
                                    <td>2.2 กลุ่มวิชาบังคับ</td>
                                        <td><?php echo e($credit8); ?></td>
                                        <td><?php echo e($count_credit_sum6); ?></td>
                                        <td><?php echo e($count_credit_6); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_6)<$credit8): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit8-($count_credit_6)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_6, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_6)<$credit8): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>


                                    <tr>
                                    <td>2.3 กลุ่มวิชาเลือก</td>
                                        <td><?php echo e($credit9); ?></td>
                                        <td><?php echo e($count_credit_sum7); ?></td>
                                        <td><?php echo e($count_credit_7); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_7)<$credit9): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit9-($count_credit_7)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
                                        
                                        
                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_7, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_7)<$credit9): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>




                                    <tr>
                                    <td><b>3. หมวดเลือกเสรี</b></td>
                                        <td><?php echo e($credit3); ?></td>
                                        <td><?php echo e($count_credit_sum8); ?></td>
                                        <td><?php echo e($count_credit_8); ?></td>
                                        <td>
                                        
                                        <?php if(($count_credit_8)<$credit3): ?>
    <button type="button" class="btn btn-danger btn-sm"><?php echo e($credit3-($count_credit_8)); ?></button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>

                                        </td>

                                  
                                        <td><?php echo e(number_format($gpa_credit_8, 2)); ?></td>
                                       

                                        <td>
                                        <?php $__currentLoopData = $course_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
    <?php if(($count_credit_8)<$credit3): ?>
    <button type="button" class="btn btn-danger btn-sm">ไม่ผ่าน</button>
    <?php else: ?>
    <button type="button" class="btn btn-success btn-sm">ผ่าน</button>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>
                                      
                                    </tr>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>












    <div class="container">
        <div class="row">
         
      
            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มวิชาภาษา <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum1); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_1, 2)); ?></h5></div>
                    <div class="card-body">
             
                      

                    
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>

                    
                    <?php endif; ?></td>

                                    
                                      
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มวิชามนุษยศาสตร์และสังคมศาสตร์ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum2); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_2, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>

                                        
                                    
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>






    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาทั่วไป กลุ่มคณิตศาสตร์และวิทยาศาสตร์ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum3); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_3, 2)); ?></h5></div>
                    <div class="card-body">
                     

              

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    

    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาพื้นฐาน <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum4); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_4, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                 
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>







    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาบังคับ <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum6); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_6, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
               
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>





    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเฉพาะ กลุ่มวิชาเลือก <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum7); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_7, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                                 
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row">
         

            <div class="col">
                <div class="card">
                    <div class="card-header"><h5>หมวดวิชาเลือกเสรี <b>หน่วยกิตที่ลงทะเบียน <?php echo e($count_credit_sum8); ?> หน่วยกิต GPA <?php echo e(number_format($gpa_credit_8, 2)); ?></h5></div>
                    <div class="card-body">
                     

                

                       
                        <br/>
                        <div class="table-responsive">
                        <table  class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>รหัสสาขาวิชา</th><th>ชื่อรายวิชา</th><th>หน่วยกิต</th><th>เกรดที่ได้</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $grade_7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->subject_id); ?></td>
                                        <td><?php echo e($item->subject_name); ?></td>
                                        <td><?php echo e($item->subject_credit); ?></td>
                                  
                                        <td>
                                        <?php if(($item->grade1)=="0"): ?>
                    F          
                    <?php elseif(($item->grade1)=="S"): ?>
                    S

                    <?php elseif(($item->grade1)=="U"): ?>
                    U

                    <?php elseif(($item->grade1)=="W"): ?>
                    W
                    <?php else: ?>
                    <span><?php echo e($item->grade1); ?></span>
                    <?php endif; ?></td>
                                        
                           
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            
                            <div class="pagination-wrapper"> <?php echo $grade->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/report/show.blade.php ENDPATH**/ ?>