

<label for="department_id" class="control-label"><?php echo e('รหัสสาขาวิชา'); ?></label>
<div class="form-group">
           
            <select class="form-control" id="department_id" name="department_id">
            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->department_id); ?>"><?php echo e($item->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

<div class="form-group <?php echo e($errors->has('course_id') ? 'has-error' : ''); ?>">
    <label for="course_id" class="control-label"><?php echo e('รหัสหลักสูตร'); ?></label>
    <input class="form-control" name="course_id" type="text" id="course_id" value="<?php echo e(isset($course->course_id) ? $course->course_id : ''); ?>" >
    <?php echo $errors->first('course_id', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group <?php echo e($errors->has('course_name') ? 'has-error' : ''); ?>">
    <label for="course_name" class="control-label"><?php echo e('ชื่อหลักสูตร'); ?></label>
    <input class="form-control" name="course_name" type="text" id="course_name" value="<?php echo e(isset($course->course_name) ? $course->course_name : ''); ?>" >
    <?php echo $errors->first('course_name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/check/resources/views/admin/courses/form.blade.php ENDPATH**/ ?>